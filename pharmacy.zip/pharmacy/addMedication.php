<!-- AddMedication.php -->


<?php if (isset($_GET['success']) && $_GET['success'] == '1'): ?>
    <p style="color: green;">Medication added successfully!</p>
<?php endif; ?>

<h1>Add Medication</h1>

<form method="POST" action="PharmacyServer.php?action=submitMedication">

    
  
    <label>Medication Name:</label>
    <input type="text" name="medicationName" required><br><br>

  
    <label>Dosage:</label>
    <input type="text" name="dosage" required><br><br>

    
    <label>Manufacturer:</label>
    <input type="text" name="manufacturer"><br><br>

    
<label>Quantity:</label>
<input type="number" name="quantity" required><br><br>

    
    <input type="submit" value="Add Medication">
</form>
