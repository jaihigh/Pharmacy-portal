<?php
session_start();
require_once '../PharmacyDatabase.php';

$db = new PharmacyDatabase();

if (!isset($_SESSION['userType'])) {
    header("Location: ../login.php");
    exit;
}

$userType = $_SESSION['userType'];

if ($userType === 'patient') {
    $userId = $_SESSION['userId'];
    $prescriptions = $db->getPrescriptionsByUser($userId);
} elseif ($userType === 'pharmacist') {
    $prescriptions = $db->getAllPrescriptionDetails(); 
} else {
    header("Location: ../login.php");
    exit;
}
?>

<html>
<head>
    <title>View Prescriptions</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 20px;
            color: #333;
        }

        h1 {
            color: rgb(0, 179, 92);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background-color: #ffffff;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }

        th, td {
            border: 1px solid #ccc;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: rgb(104, 183, 109);
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        a {
            color: #007bff;
            text-decoration: none;
            transition: color 0.3s;
        }

        a:hover {
            color: #0056b3;
        }

        .no-data {
            text-align: center;
        }
    </style>
</head>
<body>
    <h1>All Prescriptions</h1>
    <table border="1">
        <tr>
            <?php if ($userType === 'pharmacist'): ?>
                <th>Prescription ID</th>
                <th>User ID</th>
                <th>Username</th>
                <th>Medication ID</th>
            <?php endif; ?>
            <th>Medication Name</th>
            <th>Dosage</th>
            <th>Dosage Instructions</th>
            <th>Quantity</th>
            <th>Prescribed Date</th>
        </tr>

        <?php if (empty($prescriptions)): ?>
            <tr><td colspan="9">No prescriptions found.</td></tr>
        <?php else: ?>
            <?php foreach ($prescriptions as $p): ?>
                <tr>
                    <?php if ($userType === 'pharmacist'): ?>
                        <td><?= htmlspecialchars($p['prescriptionId']) ?></td>
                        <td><?= htmlspecialchars($p['userId']) ?></td>
                        <td><?= htmlspecialchars($p['userName']) ?></td>
                        <td><?= htmlspecialchars($p['medicationId']) ?></td>
                    <?php endif; ?>
                    <td><?= htmlspecialchars($p['medicationName']) ?></td>
                    <td><?= htmlspecialchars($p['dosage']) ?></td>
                    <td><?= htmlspecialchars($p['dosageInstructions']) ?></td>
                    <td><?= htmlspecialchars($p['quantity']) ?></td>
                    <td><?= htmlspecialchars($p['prescribedDate']) ?></td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
    </table>

    <a href="../PharmacyServer.php?action=home" style="color: blue; text-decoration: underline;">Back to Home</a>
</body>
</html>
