<?php
require_once 'PharmacyDatabase.php';
$db = new PharmacyDatabase();
$inventory = $db->MedicationInventory();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Medication Inventory</title>
    <style>
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #ccc; padding: 8px; }
        th { background-color:rgb(0, 179, 92); color: white; }
        tr:nth-child(even) { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <h1>Medication Inventory</h1>
    <table>
        <tr>
            <th>Medication ID</th>
            <th>Name</th>
            <th>Dosage</th>
            <th>Manufacturer</th>
            <th>Quantity</th>
            <th>Last Updated</th>
        </tr>
        <?php foreach ($inventory as $row): ?>
        <tr>
            <td><?= htmlspecialchars($row['medicationId']) ?></td>
            <td><?= htmlspecialchars($row['medicationName']) ?></td>
            <td><?= htmlspecialchars($row['dosage']) ?></td>
            <td><?= htmlspecialchars($row['manufacturer']) ?></td>
            <td><?= htmlspecialchars($row['quantityAvailable']) ?></td>
            <td><?= htmlspecialchars($row['lastUpdated']) ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
