<?php
session_start();
require_once 'PharmacyDatabase.php';

// Instantiate the database class
$db = new PharmacyDatabase();

// Fetch inventory data from the view
$inventory = $db->MedicationInventory();
?>

<style>
    h1 {
        color: rgb(0, 179, 92);
        font-family: 'Arial', sans-serif;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        background-color: #ffffff;
        font-family: 'Arial', sans-serif;
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }

    th {
        background-color: rgb(104, 183, 109); /* green header */
        color: white;
        padding: 10px;
    }

    td {
        padding: 8px;
        border: 1px solid #ccc;
    }

    tr:nth-child(even) {
        background-color: #f2f2f2;
    }
</style>
<h1>Medication Inventory</h1>
<table border="1" cellpadding="10">
    <tr>
        <th>Medication ID</th>
        <th>Name</th>
        <th>Dosage</th>
        <th>Manufacturer</th>
        <?php if ($_SESSION['userType'] === 'pharmacist'): ?>
            <th>Quantity</th>
            <th>Last Updated</th>
        <?php endif; ?>
    </tr>

    <?php foreach ($inventory as $row): ?>
        <tr>
            <td><?= htmlspecialchars($row['medicationId']) ?></td>
            <td><?= htmlspecialchars($row['medicationName']) ?></td>
            <td><?= htmlspecialchars($row['dosage']) ?></td>
            <td><?= htmlspecialchars($row['manufacturer']) ?></td>
            <?php if ($_SESSION['userType'] === 'pharmacist'): ?>
                <td><?= htmlspecialchars($row['quantityAvailable']) ?></td>
                <td><?= htmlspecialchars($row['lastUpdated']) ?></td>
            <?php endif; ?>
        </tr>
    <?php endforeach; ?>
</table>
